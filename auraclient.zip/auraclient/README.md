# Aura Client

Client-side Fabric mod for Minecraft 1.20.1 with a ClickGUI and an Aura module.

## Features

- **ClickGUI**: opens and closes with **Right Shift** (rebindable under Controls, category "Aura Client").
  - Left click on a module toggles it, right click expands its settings.
  - Number settings are sliders, mode settings cycle on click, boolean settings toggle on click.
- **Aura**
  - `Range`: flat distance from the eye position to the nearest point of the target's hitbox (1.0 to 6.0, default 3.0).
  - `Rotation`: `FunTime` or `None`.
  - `Players` and `Mobs` target filters.
- **FunTime rotation**: silent (server-side only) rotation with speed-limited smoothing, hitbox-point jitter,
  small noise, and deltas snapped to the client's mouse step. The speed, noise and jitter constants in
  `FunTimeRotation.java` are uncalibrated and not taken from any server.

## How rotations are sent

`ClientPlayerEntityMixin` swaps in the Aura rotation for the duration of `ClientPlayerEntity.sendMovementPackets`
and restores the real rotation afterwards. Rotation is computed at the start of the client tick and the attack is
sent at the end of the same tick, so the server receives the rotation packet before the attack.

## Requirements

- Minecraft 1.20.1, Fabric Loader >= 0.14.21, Fabric API 0.92.2+1.20.1
- JDK 17

## Build

```bash
gradle wrapper --gradle-version 8.5   # once, then commit gradlew, gradlew.bat and gradle/wrapper/
./gradlew build
```

The jar is written to `build/libs/auraclient-<version>.jar`. Put it in `.minecraft/mods/` together with Fabric API.

Run in a dev client with `./gradlew runClient`.

## Project layout

```
src/main/java/com/example/auraclient/
  AuraClient.java            entrypoint, keybind, tick hooks
  gui/ClickGuiScreen.java    ClickGUI
  module/                    Module, ModuleManager, AuraModule
  rotation/                  RotationManager, FunTimeRotation
  setting/Setting.java       Num / Mode / Bool settings
  util/AimMath.java          pure aim and distance math
  mixin/ClientPlayerEntityMixin.java
```

## Status

Not yet verified in game. Version pins in `gradle.properties` should be checked against your Loom setup.
