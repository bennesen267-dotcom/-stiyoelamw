package com.example.auraclient.util;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Pure helpers. Minecraft convention: yaw 0 = +Z, yaw -90 = +X, positive pitch = looking down. Degrees. */
public final class AimMath {
    private AimMath() {
    }

    public static double distanceToBox(Vec3d p, Box b) {
        double dx = Math.max(Math.max(b.minX - p.x, 0.0), p.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - p.y, 0.0), p.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - p.z, 0.0), p.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static float[] anglesTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        return new float[]{yaw, pitch};
    }

    /** Degrees of rotation produced by one raw mouse count at the given sensitivity option value (0..1). */
    public static double mouseStepDegrees(double sensitivity) {
        double f = sensitivity * 0.6 + 0.2;
        return f * f * f * 1.2;
    }

    public static float quantize(float delta, double step) {
        if (step <= 0.0) {
            return delta;
        }
        return (float) (Math.round(delta / step) * step);
    }
}
