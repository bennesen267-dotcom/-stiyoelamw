package com.example.auraclient.module;

import com.example.auraclient.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    private final String name;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public List<Setting> settings() {
        return Collections.unmodifiableList(settings);
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (value == enabled) {
            return;
        }
        enabled = value;
        if (value) {
            onEnable();
        } else {
            onDisable();
        }
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public void preTick(MinecraftClient mc) {
    }

    public void postTick(MinecraftClient mc) {
    }
}
