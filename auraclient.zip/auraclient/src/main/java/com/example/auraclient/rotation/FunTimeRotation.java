package com.example.auraclient.rotation;

import com.example.auraclient.util.AimMath;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * "FunTime" rotation mode: speed-limited smoothing toward a jittered point inside the hitbox,
 * with small noise and per-tick deltas snapped to the client's mouse step (sensitivity-derived).
 * All speed, noise and jitter constants below are UNCALIBRATED guesses, not values taken from any server.
 */
public final class FunTimeRotation {
    private final Random rng = new Random();
    private int lastTargetId = Integer.MIN_VALUE;
    private double offX;
    private double offY;
    private double offZ;
    private int rerollIn;

    public void reset() {
        lastTargetId = Integer.MIN_VALUE;
        rerollIn = 0;
    }

    /** @return {newYaw, newPitch}; yaw stays continuous with curYaw (not wrapped). */
    public float[] next(int targetId, float curYaw, float curPitch, Vec3d eye, Box box, double mouseSensitivity) {
        if (targetId != lastTargetId || --rerollIn <= 0) {
            reroll();
            lastTargetId = targetId;
        }

        float[] want = AimMath.anglesTo(eye, aimPoint(eye, box));
        float dYaw = MathHelper.wrapDegrees(want[0] - curYaw);
        float dPitch = want[1] - curPitch;

        float maxYaw = 28.0f + rng.nextFloat() * 22.0f;
        float maxPitch = 14.0f + rng.nextFloat() * 10.0f;
        float factor = 0.55f + rng.nextFloat() * 0.25f;

        float stepYaw = MathHelper.clamp(dYaw * factor, -maxYaw, maxYaw) + (float) (rng.nextGaussian() * 0.2);
        float stepPitch = MathHelper.clamp(dPitch * factor, -maxPitch, maxPitch) + (float) (rng.nextGaussian() * 0.2);

        double mouseStep = AimMath.mouseStepDegrees(mouseSensitivity);
        float newYaw = curYaw + AimMath.quantize(stepYaw, mouseStep);
        float newPitch = MathHelper.clamp(curPitch + AimMath.quantize(stepPitch, mouseStep), -90.0f, 90.0f);
        return new float[]{newYaw, newPitch};
    }

    private Vec3d aimPoint(Vec3d eye, Box box) {
        double width = box.maxX - box.minX;
        double depth = box.maxZ - box.minZ;
        double height = box.maxY - box.minY;
        double x = (box.minX + box.maxX) * 0.5 + offX * width;
        double z = (box.minZ + box.maxZ) * 0.5 + offZ * depth;
        double y = MathHelper.clamp(eye.y + offY * height, box.minY + height * 0.15, box.maxY - height * 0.10);
        return new Vec3d(x, y, z);
    }

    private void reroll() {
        offX = (rng.nextDouble() * 2.0 - 1.0) * 0.25;
        offZ = (rng.nextDouble() * 2.0 - 1.0) * 0.25;
        offY = (rng.nextDouble() * 2.0 - 1.0) * 0.20;
        rerollIn = 6 + rng.nextInt(10);
    }
}
