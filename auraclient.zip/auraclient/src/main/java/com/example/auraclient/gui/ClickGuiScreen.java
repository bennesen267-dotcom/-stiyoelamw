package com.example.auraclient.gui;

import com.example.auraclient.module.Module;
import com.example.auraclient.module.ModuleManager;
import com.example.auraclient.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class ClickGuiScreen extends Screen {
    private static final int X = 30;
    private static final int Y = 30;
    private static final int W = 150;
    private static final int ROW = 16;
    private static final Set<Module> EXPANDED = new HashSet<>();

    private Setting.Num dragging;

    private record Row(int y, Module module, Setting setting) {
    }

    public ClickGuiScreen() {
        super(Text.literal("ClickGUI"));
    }

    private List<Row> layout() {
        List<Row> rows = new ArrayList<>();
        int y = Y + ROW;
        for (Module m : ModuleManager.all()) {
            rows.add(new Row(y, m, null));
            y += ROW;
            if (EXPANDED.contains(m)) {
                for (Setting s : m.settings()) {
                    rows.add(new Row(y, m, s));
                    y += ROW;
                }
            }
        }
        return rows;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.fill(X, Y, X + W, Y + ROW, 0xFF111111);
        ctx.drawTextWithShadow(textRenderer, "Combat", X + 4, Y + 4, 0xFFFFFFFF);

        for (Row r : layout()) {
            int y = r.y();
            if (r.setting() == null) {
                Module m = r.module();
                ctx.fill(X, y, X + W, y + ROW, m.isEnabled() ? 0xFF2E7D32 : 0xFF2B2B2B);
                ctx.drawTextWithShadow(textRenderer, m.name(), X + 4, y + 4, 0xFFFFFFFF);
                ctx.drawTextWithShadow(textRenderer, EXPANDED.contains(m) ? "-" : "+", X + W - 10, y + 4, 0xFFAAAAAA);
                continue;
            }
            ctx.fill(X, y, X + W, y + ROW, 0xFF1B1B1B);
            Setting s = r.setting();
            String label;
            if (s instanceof Setting.Num n) {
                ctx.fill(X, y, X + (int) (W * n.ratio()), y + ROW, 0xFF3A5FCD);
                label = n.name() + ": " + String.format(Locale.ROOT, "%.1f", n.get());
            } else if (s instanceof Setting.Mode mode) {
                label = mode.name() + ": " + mode.get();
            } else if (s instanceof Setting.Bool b) {
                label = b.name() + ": " + (b.get() ? "ON" : "OFF");
            } else {
                label = s.name();
            }
            ctx.drawTextWithShadow(textRenderer, label, X + 6, y + 4, 0xFFFFFFFF);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (mouseX >= X && mouseX < X + W) {
            for (Row r : layout()) {
                if (mouseY >= r.y() && mouseY < r.y() + ROW) {
                    handleClick(r, mouseX, button);
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void handleClick(Row r, double mouseX, int button) {
        if (r.setting() == null) {
            Module m = r.module();
            if (button == 0) {
                m.toggle();
            } else if (button == 1) {
                if (!EXPANDED.remove(m)) {
                    EXPANDED.add(m);
                }
            }
            return;
        }
        if (button != 0) {
            return;
        }
        Setting s = r.setting();
        if (s instanceof Setting.Num n) {
            dragging = n;
            n.setFromRatio((mouseX - X) / W);
        } else if (s instanceof Setting.Mode mode) {
            mode.cycle();
        } else if (s instanceof Setting.Bool b) {
            b.toggle();
        }
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging != null && button == 0) {
            dragging.setFromRatio((mouseX - X) / W);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
