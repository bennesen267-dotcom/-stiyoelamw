package com.example.auraclient.rotation;

public final class RotationManager {
    public static final RotationManager INSTANCE = new RotationManager();

    private boolean active;
    private float yaw;
    private float pitch;

    private RotationManager() {
    }

    public boolean isActive() {
        return active;
    }

    public float yaw() {
        return yaw;
    }

    public float pitch() {
        return pitch;
    }

    public void set(float yaw, float pitch) {
        if (!Float.isFinite(yaw) || !Float.isFinite(pitch)) {
            return;
        }
        this.yaw = yaw;
        this.pitch = pitch;
        this.active = true;
    }

    public void stop() {
        active = false;
    }
}
