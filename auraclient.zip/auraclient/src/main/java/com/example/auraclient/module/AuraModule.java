package com.example.auraclient.module;

import com.example.auraclient.rotation.FunTimeRotation;
import com.example.auraclient.rotation.RotationManager;
import com.example.auraclient.setting.Setting;
import com.example.auraclient.util.AimMath;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class AuraModule extends Module {
    // Range is the flat distance from the eye position to the nearest point of the target's hitbox.
    private final Setting.Num range = add(new Setting.Num("Range", 3.0, 1.0, 6.0, 0.1));
    private final Setting.Mode rotation = add(new Setting.Mode("Rotation", new String[]{"FunTime", "None"}, 0));
    private final Setting.Bool players = add(new Setting.Bool("Players", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mobs", false));

    private final FunTimeRotation funTime = new FunTimeRotation();
    private LivingEntity target;

    public AuraModule() {
        super("Aura");
    }

    @Override
    protected void onDisable() {
        target = null;
        funTime.reset();
        RotationManager.INSTANCE.stop();
    }

    @Override
    public void preTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || !player.isAlive()) {
            target = null;
            funTime.reset();
            RotationManager.INSTANCE.stop();
            return;
        }

        target = findTarget(mc);
        if (target == null) {
            funTime.reset();
            RotationManager.INSTANCE.stop();
            return;
        }

        if (rotation.is("FunTime")) {
            RotationManager rm = RotationManager.INSTANCE;
            if (!rm.isActive()) {
                rm.set(player.getYaw(), player.getPitch());
            }
            double sensitivity = mc.options.getMouseSensitivity().getValue();
            float[] next = funTime.next(target.getId(), rm.yaw(), rm.pitch(),
                    player.getEyePos(), target.getBoundingBox(), sensitivity);
            rm.set(next[0], next[1]);
        } else {
            RotationManager.INSTANCE.stop();
        }
    }

    @Override
    public void postTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        LivingEntity t = target;
        if (player == null || mc.interactionManager == null || t == null || t.isRemoved() || !t.isAlive()) {
            return;
        }
        if (player.getAttackCooldownProgress(0.5f) < 0.92f) {
            return;
        }
        if (AimMath.distanceToBox(player.getEyePos(), t.getBoundingBox()) > range.get()) {
            return;
        }
        if (rotation.is("FunTime") && !isLookingAt(player, t)) {
            return;
        }
        mc.interactionManager.attackEntity(player, t);
        player.swingHand(Hand.MAIN_HAND);
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        Vec3d eye = mc.player.getEyePos();
        double maxRange = range.get();
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living) || e == mc.player) {
                continue;
            }
            if (!living.isAlive() || living.isSpectator()) {
                continue;
            }
            boolean isPlayer = e instanceof PlayerEntity;
            if (isPlayer ? !players.get() : !(mobs.get() && e instanceof MobEntity)) {
                continue;
            }
            double d = AimMath.distanceToBox(eye, living.getBoundingBox());
            if (d > maxRange || d >= bestDistance) {
                continue;
            }
            best = living;
            bestDistance = d;
        }
        return best;
    }

    private boolean isLookingAt(ClientPlayerEntity player, LivingEntity t) {
        RotationManager rm = RotationManager.INSTANCE;
        Vec3d eye = player.getEyePos();
        Vec3d look = Vec3d.fromPolar(rm.pitch(), rm.yaw());
        Vec3d end = eye.add(look.multiply(range.get()));
        Box box = t.getBoundingBox();
        return box.contains(eye) || box.raycast(eye, end).isPresent();
    }
}
