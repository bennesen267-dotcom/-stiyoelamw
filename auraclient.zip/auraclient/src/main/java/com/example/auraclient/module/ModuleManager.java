package com.example.auraclient.module;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    public static final AuraModule AURA = register(new AuraModule());

    private ModuleManager() {
    }

    private static <T extends Module> T register(T module) {
        MODULES.add(module);
        return module;
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    public static void preTick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.isEnabled()) {
                m.preTick(mc);
            }
        }
    }

    public static void postTick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.isEnabled()) {
                m.postTick(mc);
            }
        }
    }
}
