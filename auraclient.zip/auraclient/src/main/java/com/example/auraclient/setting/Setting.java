package com.example.auraclient.setting;

public abstract class Setting {
    private final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

    public static final class Num extends Setting {
        private final double min;
        private final double max;
        private final double step;
        private double value;

        public Num(String name, double value, double min, double max, double step) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.value = clamp(value);
        }

        public double get() {
            return value;
        }

        public void set(double v) {
            value = clamp(Math.round(v / step) * step);
        }

        public void setFromRatio(double ratio) {
            double r = Math.max(0.0, Math.min(1.0, ratio));
            set(min + r * (max - min));
        }

        public double ratio() {
            return (value - min) / (max - min);
        }

        private double clamp(double v) {
            return Math.max(min, Math.min(max, v));
        }
    }

    public static final class Mode extends Setting {
        private final String[] modes;
        private int index;

        public Mode(String name, String[] modes, int index) {
            super(name);
            this.modes = modes.clone();
            this.index = index;
        }

        public String get() {
            return modes[index];
        }

        public boolean is(String mode) {
            return modes[index].equals(mode);
        }

        public void cycle() {
            index = (index + 1) % modes.length;
        }
    }

    public static final class Bool extends Setting {
        private boolean value;

        public Bool(String name, boolean value) {
            super(name);
            this.value = value;
        }

        public boolean get() {
            return value;
        }

        public void toggle() {
            value = !value;
        }
    }
}
