package com.example.auraclient;

import com.example.auraclient.gui.ClickGuiScreen;
import com.example.auraclient.module.ModuleManager;
import com.example.auraclient.rotation.RotationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class AuraClient implements ClientModInitializer {
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.auraclient.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.auraclient"));

        // Runs before the player tick: rotations are computed here so the movement packet carries them.
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) {
                RotationManager.INSTANCE.stop();
                return;
            }
            while (openGui.wasPressed()) {
                if (mc.currentScreen == null) {
                    mc.setScreen(new ClickGuiScreen());
                }
            }
            ModuleManager.preTick(mc);
        });

        // Runs after the player tick (movement packet already queued): attacks go out after the rotation.
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.world == null) {
                return;
            }
            ModuleManager.postTick(mc);
        });
    }
}
