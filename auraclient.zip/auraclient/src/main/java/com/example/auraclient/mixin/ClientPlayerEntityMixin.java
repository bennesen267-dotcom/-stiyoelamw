package com.example.auraclient.mixin;

import com.example.auraclient.rotation.RotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Swaps the rotation sent to the server for the duration of sendMovementPackets, then restores the real one. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique private float auraclient$realYaw;
    @Unique private float auraclient$realPitch;
    @Unique private boolean auraclient$applied;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void auraclient$applyRotation(CallbackInfo ci) {
        RotationManager rm = RotationManager.INSTANCE;
        if (!rm.isActive()) {
            auraclient$applied = false;
            return;
        }
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        auraclient$realYaw = self.getYaw();
        auraclient$realPitch = self.getPitch();
        self.setYaw(rm.yaw());
        self.setPitch(rm.pitch());
        auraclient$applied = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void auraclient$restoreRotation(CallbackInfo ci) {
        if (!auraclient$applied) {
            return;
        }
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(auraclient$realYaw);
        self.setPitch(auraclient$realPitch);
        auraclient$applied = false;
    }
}
